# MINI-PROJECT
To Demonstrate all the Sorting algorithms.
